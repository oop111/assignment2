import com.aitu.assignment2.train.*;
import com.aitu.assignment2.train.wagons.*;
import com.aitu.assignment2.train.wagons.passengers.*;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);
    static void mainMenu(){
        System.out.println("Choose action: ");
        System.out.println("1. Enter the System");
        System.out.println("0. Exit");
        System.out.println();
    }
    static void trainManagement(){
        System.out.println("Choose action: ");
        System.out.println("1. Add train");
        System.out.println("2. View trains");
        System.out.println("0. Go back");
        System.out.println();
    }
    static ArrayList<Object> addingTrain(){
        ArrayList arr = new ArrayList();
        System.out.println("Set direction: ");
        String str = sc.next();
        arr.add(str);
        System.out.println("Set time");
        str = sc.next();
        arr.add(str);
        System.out.println("Set amount of wagons");
        int temp = sc.nextInt();
        arr.add(temp);
        System.out.println("Set speed");
        temp = sc.nextInt();
        arr.add(temp);
        System.out.println("Set type of train");
        str = sc.next();
        arr.add(str);
        System.out.println();
        return arr;
    }
    static void trainManagementView(){
        System.out.println("Choose action: ");
        System.out.println("1. Add train");
        System.out.println("2. Manage train");
        System.out.println("3. View wagons");
        System.out.println("0. Go back");
        System.out.println();
    }
    static void trainManagementViewManage(){
        System.out.println("Choose action: ");
        System.out.println("1. Delete train");
        System.out.println("2. Set new type of train");
        System.out.println("3. Change the direction");
        System.out.println("4. Change the time");
        System.out.println("5. Change the amount of wagons");
        System.out.println("6. Change speed");
        System.out.println("0. Go back");
        System.out.println();
    }
    static void wagonManagementView(){
        System.out.println("Choose action: ");
        System.out.println("1. Add wagon");
        System.out.println("2. Manage wagon");
        System.out.println("3. View passengers");
        System.out.println("0. Go back");
        System.out.println();
    }
    static void wagonType(){
        System.out.println("Choose wagon type:");
        System.out.println("1. Common wagon");
        System.out.println("2. Wagon for disabled people");
        System.out.println("3. Lux wagon");
        System.out.println("4. Restaurant");
        System.out.println("0. Go back");
        System.out.println();
    }
    static void wagonManagementViewManage(){
        System.out.println("Choose action: ");
        System.out.println("1. Delete wagon");
        System.out.println("2. Change wagon capacity");
        System.out.println("0. Go back");
        System.out.println();
    }
    static void passengerManagement(){
        System.out.println("Choose action: ");
        System.out.println("1. Add passenger");
        System.out.println("2. Manage an information about passenger");
        System.out.println("3. Delete Passenger");
        System.out.println("0. Go back");
        System.out.println();
    }
    static void passengerType(){
        System.out.println("Choose passenger");
        System.out.println("1. Common passenger");
        System.out.println("2. Retired");
        System.out.println("3. Student");
        System.out.println("4. Child");
    }
    static void passengerManage(){
        System.out.println("Choose action: ");
        System.out.println("1. Choose another seat");
        System.out.println("2. Set new name");
        System.out.println("3. Set new surname");
        System.out.println("4. Set new age");
        System.out.println("5. Change the wagon");
        System.out.println("0. Go back");
        System.out.println();
    }
    static ArrayList addingPassenger(){
        ArrayList arr = new ArrayList();
        System.out.println("Choose a seat: ");
        int temp = sc.nextInt();
        arr.add(temp);
        System.out.println("Set name");
        String str = sc.next();
        arr.add(str);
        System.out.println("Set surname");
        str = sc.next();
        arr.add(str);
        System.out.println("Set age");
        temp = sc.nextInt();
        arr.add(temp);
        System.out.println();
        return arr;
    }
    static boolean isChild(int age){
        return age <= 6;
    }
    static boolean isRetired(int age){
        return age >= 50;
    }
    static void addingPassengerCode(ArrayList<Train> trains, int i){
        int choice;
        System.out.println("Choose action: ");
        System.out.println("1. Add passenger");
        System.out.println("2. Continue adding wagons");
        System.out.println("0. Go back");
        choice = sc.nextInt();
        if(choice == 1) {
            for (int j = 0; j < trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getWagonCapacity(); j++){
                passengerType();
                choice = sc.nextInt();
                ArrayList newpass = addingPassenger();
                int t = trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getPassengers().size();
                if (choice == 1) {
                    trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).enrollPassenger(new Passenger((Integer) newpass.get(0), (String) newpass.get(1), (String) newpass.get(2), (Integer) newpass.get(3)));
                    if (trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getPassengers().size() == (t + 1)) {
                        System.out.println("A new passenger has been added");
                        System.out.println(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getPassengers().get(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getPassengers().size() - 1));
                        System.out.println("Choose action: ");
                        System.out.println("1. Continue adding passengers");
                        System.out.println("0. Go back");
                        choice = sc.nextInt();
                        if (choice == 1) {

                        } else if (choice == 0) {
                            j = trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getWagonCapacity();
                        }
                        else {
                            System.out.println("Choose the number from the list!");
                        }

                    } else {
                        System.out.println("Choose action: ");
                        System.out.println("1. Continue adding passengers");
                        System.out.println("0. Go back");
                        choice = sc.nextInt();
                        if (choice == 1) {

                        } else if (choice == 0) {
                            j = trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getWagonCapacity();
                        }
                        else {
                            System.out.println("Choose the number from the list!");
                        }
                    }
                } else if (choice == 2) {
                    if (isRetired((Integer) newpass.get(3))) {
                        trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).enrollPassenger(new Retired((Integer) newpass.get(0), (String) newpass.get(1), (String) newpass.get(2), (Integer) newpass.get(3)));
                        if (trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getPassengers().size() == (t + 1)) {
                            System.out.println("A new passenger has been added");
                            System.out.println(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getPassengers().get(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getPassengers().size() - 1));
                            System.out.println("Choose action: ");
                            System.out.println("1. Continue adding passengers");
                            System.out.println("0. Go back");
                            choice = sc.nextInt();
                            if (choice == 1) {

                            } else if (choice == 0) {
                                j = trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getWagonCapacity();
                            }
                            else {
                                System.out.println("Choose the number from the list!");
                            }
                        } else {
                            System.out.println("Choose action: ");
                            System.out.println("1. Continue adding passengers");
                            System.out.println("0. Go back");
                            choice = sc.nextInt();
                            if (choice == 1) {

                            } else if (choice == 0) {
                                j = trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getWagonCapacity();
                            }
                            else {
                                System.out.println("Choose the number from the list!");
                            }
                        }
                    } else {
                        System.out.println("Passenger is not retired");
                    }
                } else if (choice == 3) {
                    trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).enrollPassenger(new Student((Integer) newpass.get(0), (String) newpass.get(1), (String) newpass.get(2), (Integer) newpass.get(3)));
                    if (trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getPassengers().size() == (t + 1)) {
                        System.out.println("A new passenger has been added");
                        System.out.println(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getPassengers().get(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getPassengers().size() - 1));
                        System.out.println("Choose action: ");
                        System.out.println("1. Continue adding passengers");
                        System.out.println("0. Go back");
                        choice = sc.nextInt();
                        if (choice == 1) {

                        } else if (choice == 0) {
                            j = trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getWagonCapacity();
                        }
                        else {
                            System.out.println("Choose the number from the list!");
                        }
                    } else {
                        System.out.println("Choose action: ");
                        System.out.println("1. Continue adding passengers");
                        System.out.println("0. Go back");
                        choice = sc.nextInt();
                        if (choice == 1) {

                        } else if (choice == 0) {
                            j = trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getWagonCapacity();
                        }
                        else {
                            System.out.println("Choose the number from the list!");
                        }
                    }
                } else if (choice == 4) {
                    if (isChild((Integer) newpass.get(3))) {
                        trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).enrollPassenger(new Child((Integer) newpass.get(0), (String) newpass.get(1), (String) newpass.get(2), (Integer) newpass.get(3)));
                        if (trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getPassengers().size() == (t + 1)) {
                            System.out.println("A new passenger has been added");
                            System.out.println(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getPassengers().get(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getPassengers().size() - 1));
                            System.out.println("Choose action: ");
                            System.out.println("1. Continue adding passengers");
                            System.out.println("0. Go back");
                            choice = sc.nextInt();
                            if (choice == 1) {

                            } else if (choice == 0) {
                                j = trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getWagonCapacity();
                            }
                            else {
                                System.out.println("Choose the number from the list!");
                            }
                        } else {
                            System.out.println("Choose action: ");
                            System.out.println("1. Continue adding passengers");
                            System.out.println("0. Go back");
                            choice = sc.nextInt();
                            if (choice == 1) {

                            } else if (choice == 0) {
                                j = trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getWagonCapacity();
                            }
                            else {
                                System.out.println("Choose the number from the list!");
                            }
                        }
                    } else {
                        System.out.println("Passenger is not a child");
                    }

                }
            }
        }else if(choice == 2){
            if(i < trains.get(trains.size() - 1).getAmountOfWagons()){
                System.out.println("You reached maximum amount of wagons that can be created");
            }
        }else if(choice == 0){
            i = trains.get(trains.size() - 1).getAmountOfWagons();
        }
        else {
            System.out.println("Choose the number from the list!");
        }
    }
    public static void main(String[] args) {
        ArrayList<Train> trains = new ArrayList<Train>();
        while (true){
            mainMenu();
            int choice = sc.nextInt();
            if(choice == 1){
                trainManagement();
                choice = sc.nextInt();
                if(choice == 1){
                    ArrayList tValues = addingTrain();
                    trains.add(new Train((String) tValues.get(0), (String) tValues.get(1), (Integer) tValues.get(2), (Integer) tValues.get(3), (String) tValues.get(4)));
                    System.out.println(trains.get(trains.size() - 1));
                    for(int i = 0; i < trains.get(trains.size() - 1).getAmountOfWagons(); i++){
                        System.out.println("Add " + (i+1) + " wagon:");
                        wagonType();
                        choice = sc.nextInt();
                        if(choice == 1){
                            System.out.println("Write down the max number of passengers: ");
                            choice = sc.nextInt();
                            trains.get(trains.size() - 1).enrollWagon(new CommonWagon(choice));
                            System.out.println(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() -1));
                            addingPassengerCode(trains, i);
                        }else if(choice == 2){
                            System.out.println("Write down the max number of passengers: ");
                            choice = sc.nextInt();
                            trains.get(trains.size() - 1).enrollWagon(new DisWagon(choice));
                            System.out.println(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() -1));
                            addingPassengerCode(trains, i);
                        }else if(choice == 3){
                            System.out.println("Write down the max number of passengers: ");
                            choice = sc.nextInt();
                            trains.get(trains.size() - 1).enrollWagon(new LuxWagon(choice));
                            System.out.println(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() -1));
                            addingPassengerCode(trains, i);
                        }else if(choice == 4){
                            System.out.println("Write down the max number of passengers: ");
                            choice = sc.nextInt();
                            trains.get(trains.size() - 1).enrollWagon(new Restaurant(choice));
                            System.out.println(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() -1));
                            addingPassengerCode(trains, i);
                        }else if(choice == 0){
                            i = trains.get(trains.size() - 1).getAmountOfWagons();
                        }
                        else {
                            System.out.println("Choose the number from the list!");
                        }
                    }
                } else if (choice == 2) {
                    for(Train t: trains){
                        System.out.println(t);
                    }
                    trainManagementView();
                    choice = sc.nextInt();
                    if(choice == 1){
                        ArrayList tValues = addingTrain();
                        trains.add(new Train((String) tValues.get(0), (String) tValues.get(1), (Integer) tValues.get(2), (Integer) tValues.get(3), (String) tValues.get(4)));
                        System.out.println(trains.get(trains.size() - 1));
                        for(int i = 0; i < trains.get(trains.size() - 1).getAmountOfWagons(); i++){
                            System.out.println("Add " + (i+1) + " wagon:");
                            wagonType();
                            choice = sc.nextInt();
                            if(choice == 1){
                                System.out.println("Write down the max number of passengers: ");
                                choice = sc.nextInt();
                                trains.get(trains.size() - 1).enrollWagon(new CommonWagon(choice));
                                System.out.println(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() -1));
                                addingPassengerCode(trains, i);
                            }else if(choice == 2){
                                System.out.println("Write down the max number of passengers: ");
                                choice = sc.nextInt();
                                trains.get(trains.size() - 1).enrollWagon(new DisWagon(choice));
                                System.out.println(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() -1));
                                addingPassengerCode(trains, i);
                            }else if(choice == 3){
                                System.out.println("Write down the max number of passengers: ");
                                choice = sc.nextInt();
                                trains.get(trains.size() - 1).enrollWagon(new LuxWagon(choice));
                                System.out.println(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() -1));
                                addingPassengerCode(trains, i);
                            }else if(choice == 4){
                                System.out.println("Write down the max number of passengers: ");
                                choice = sc.nextInt();
                                trains.get(trains.size() - 1).enrollWagon(new Restaurant(choice));
                                System.out.println(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() -1));
                                addingPassengerCode(trains, i);
                            }else if(choice == 0){
                                i = trains.get(trains.size() - 1).getAmountOfWagons();
                            }
                            else {
                                System.out.println("Choose the number from the list!");
                            }
                        }
                    } else if(choice == 2){
                        System.out.println("Train number?");
                        int num = sc.nextInt();
                        trainManagementViewManage();
                        choice = sc.nextInt();
                        String str;
                        if(choice == 1){
                            trains.remove(num-1);
                            System.out.println("Train was deleted");
                        }else if(choice == 2){
                            System.out.println("Write a new type of train: ");
                            str = sc.next();
                            trains.get(num-1).setTrainType(str);
                        }else if(choice == 3){
                            System.out.println("Write the new direction of the train: ");
                            str = sc.next();
                            trains.get(num-1).setDirection(str);
                        }else if(choice == 4){
                            System.out.println("Write new time of train arrival: ");
                            str = sc.next();
                            trains.get(num-1).setTime(str);
                        }else if(choice == 5){
                            System.out.println("Write the new amount of wagons of the train: ");
                            int temp = sc.nextInt();
                            trains.get(num-1).setAmountOfWagons(temp);
                        }else if(choice == 6){
                            System.out.println("Write the new train speed: ");
                            str = sc.next();
                            trains.get(num-1).setTrainType(str);
                        }else if(choice == 0){
                            continue;
                        }
                        else {
                            System.out.println("Choose the number from the list!");
                        }
                    } else if(choice == 3){
                        System.out.println("Train number?");
                        int num = sc.nextInt();
                        System.out.println(trains.get(num-1).getWagons());
                        wagonManagementView();
                        choice = sc.nextInt();
                        if(choice == 1){
                            System.out.println("Add wagon:");
                            wagonType();
                            choice = sc.nextInt();
                            if(choice == 1){
                                System.out.println("Write down the max number of passengers: ");
                                choice = sc.nextInt();
                                trains.get(trains.size() - 1).enrollWagon(new CommonWagon(choice));
                                System.out.println(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() -1));
                                addingPassengerCode(trains, 0);
                            }else if(choice == 2){
                                System.out.println("Write down the max number of passengers: ");
                                choice = sc.nextInt();
                                trains.get(trains.size() - 1).enrollWagon(new DisWagon(choice));
                                System.out.println(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() -1));
                                addingPassengerCode(trains, 0);
                            }else if(choice == 3){
                                System.out.println("Write down the max number of passengers: ");
                                choice = sc.nextInt();
                                trains.get(trains.size() - 1).enrollWagon(new LuxWagon(choice));
                                System.out.println(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() -1));
                                addingPassengerCode(trains, 0);
                            }else if(choice == 4){
                                System.out.println("Write down the max number of passengers: ");
                                choice = sc.nextInt();
                                trains.get(trains.size() - 1).enrollWagon(new Restaurant(choice));
                                System.out.println(trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() -1));
                                addingPassengerCode(trains, 0);
                            }else if(choice == 0){
                                continue;
                            }
                            else {
                                System.out.println("Choose the number from the list!");
                            }
                        } else if (choice == 2) {
                            System.out.println("Number of wagon?");
                            int num1 = sc.nextInt();
                            wagonManagementViewManage();
                            choice = sc.nextInt();
                            if(choice == 1){
                                trains.get(num-1).getWagons().remove(num1-1);
                            } else if (choice == 2) {
                                System.out.println("Write new capacity: ");
                                int num2 = sc.nextInt();
                                trains.get(num-1).getWagons().get(num1-1).setWagonCapacity(num2);
                                System.out.println("Data was updated");
                            } else if (choice == 0) {
                                continue;
                            }
                            else {
                                System.out.println("Choose the number from the list!");
                            }
                        } else if (choice == 3) {
                            System.out.println("Wagon number?");
                            int num1 = sc.nextInt();
                            System.out.println(trains.get(num-1).getWagons().get(num1-1).getPassengers());
                            passengerManagement();
                            choice = sc.nextInt();
                            if(choice == 1){
                                for (int j = trains.get(num-1).getWagons().get(num1-1).getPassengers().size() - 1; j < trains.get(num-1).getWagons().get(num1-1).getWagonCapacity(); j++){
                                    passengerType();
                                    choice = sc.nextInt();
                                    ArrayList newpass = addingPassenger();
                                    int t = trains.get(num-1).getWagons().get(num1-1).getPassengers().size();
                                    if (choice == 1) {
                                        trains.get(num-1).getWagons().get(num1-1).enrollPassenger(new Passenger((Integer) newpass.get(0), (String) newpass.get(1), (String) newpass.get(2), (Integer) newpass.get(3)));
                                        if (trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getPassengers().size() == (t + 1)) {
                                            System.out.println("A new passenger has been added");
                                            System.out.println(trains.get(num-1).getWagons().get(num1-1).getPassengers().get(trains.get(num-1).getWagons().get(num1-1).getPassengers().size()-1));
                                            System.out.println("Choose action: ");
                                            System.out.println("1. Continue adding passengers");
                                            System.out.println("0. Go back");
                                            choice = sc.nextInt();
                                            if (choice == 1) {

                                            } else if (choice == 0) {
                                                j = trains.get(num-1).getWagons().get(num1-1).getWagonCapacity();
                                            }
                                            else {
                                                System.out.println("Choose the number from the list!");
                                            }

                                        } else {
                                            System.out.println("Choose action: ");
                                            System.out.println("1. Continue adding passengers");
                                            System.out.println("0. Go back");
                                            choice = sc.nextInt();
                                            if (choice == 1) {

                                            } else if (choice == 0) {
                                                j = trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getWagonCapacity();
                                            }
                                            else {
                                                System.out.println("Choose the number from the list!");
                                            }
                                        }
                                    } else if (choice == 2) {
                                        if (isRetired((Integer) newpass.get(3))) {
                                            trains.get(num-1).getWagons().get(num1-1).enrollPassenger(new Retired((Integer) newpass.get(0), (String) newpass.get(1), (String) newpass.get(2), (Integer) newpass.get(3)));
                                            if (trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getPassengers().size() == (t + 1)) {
                                                System.out.println("A new passenger has been added");
                                                System.out.println(trains.get(num-1).getWagons().get(num1-1).getPassengers().get(trains.get(num-1).getWagons().get(num1-1).getPassengers().size()-1));
                                                System.out.println("Choose action: ");
                                                System.out.println("1. Continue adding passengers");
                                                System.out.println("0. Go back");
                                                choice = sc.nextInt();
                                                if (choice == 1) {

                                                } else if (choice == 0) {
                                                    j = trains.get(num-1).getWagons().get(num1-1).getWagonCapacity();
                                                }
                                                else {
                                                    System.out.println("Choose the number from the list!");
                                                }

                                            } else {
                                                System.out.println("Choose action: ");
                                                System.out.println("1. Continue adding passengers");
                                                System.out.println("0. Go back");
                                                choice = sc.nextInt();
                                                if (choice == 1) {

                                                } else if (choice == 0) {
                                                    j = trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getWagonCapacity();
                                                }
                                                else {
                                                    System.out.println("Choose the number from the list!");
                                                }
                                            }
                                        } else {
                                            System.out.println("Passenger is not retired");
                                        }
                                    } else if (choice == 3) {
                                        trains.get(num-1).getWagons().get(num1-1).enrollPassenger(new Student((Integer) newpass.get(0), (String) newpass.get(1), (String) newpass.get(2), (Integer) newpass.get(3)));
                                        if (trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getPassengers().size() == (t + 1)) {
                                            System.out.println("A new passenger has been added");
                                            System.out.println(trains.get(num-1).getWagons().get(num1-1).getPassengers().get(trains.get(num-1).getWagons().get(num1-1).getPassengers().size()-1));
                                            System.out.println("Choose action: ");
                                            System.out.println("1. Continue adding passengers");
                                            System.out.println("0. Go back");
                                            choice = sc.nextInt();
                                            if (choice == 1) {

                                            } else if (choice == 0) {
                                                j = trains.get(num-1).getWagons().get(num1-1).getWagonCapacity();
                                            }
                                            else {
                                                System.out.println("Choose the number from the list!");
                                            }

                                        } else {
                                            System.out.println("Choose action: ");
                                            System.out.println("1. Continue adding passengers");
                                            System.out.println("0. Go back");
                                            choice = sc.nextInt();
                                            if (choice == 1) {

                                            } else if (choice == 0) {
                                                j = trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getWagonCapacity();
                                            }
                                            else {
                                                System.out.println("Choose the number from the list!");
                                            }
                                        }
                                    } else if (choice == 4) {
                                        if (isChild((Integer) newpass.get(3))) {
                                            trains.get(num-1).getWagons().get(num1-1).enrollPassenger(new Child((Integer) newpass.get(0), (String) newpass.get(1), (String) newpass.get(2), (Integer) newpass.get(3)));
                                            if (trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getPassengers().size() == (t + 1)) {
                                                System.out.println("A new passenger has been added");
                                                System.out.println(trains.get(num-1).getWagons().get(num1-1).getPassengers().get(trains.get(num-1).getWagons().get(num1-1).getPassengers().size()-1));
                                                System.out.println("Choose action: ");
                                                System.out.println("1. Continue adding passengers");
                                                System.out.println("0. Go back");
                                                choice = sc.nextInt();
                                                if (choice == 1) {

                                                } else if (choice == 0) {
                                                    j = trains.get(num-1).getWagons().get(num1-1).getWagonCapacity();
                                                }
                                                else {
                                                    System.out.println("Choose the number from the list!");
                                                }

                                            } else {
                                                System.out.println("Choose action: ");
                                                System.out.println("1. Continue adding passengers");
                                                System.out.println("0. Go back");
                                                choice = sc.nextInt();
                                                if (choice == 1) {

                                                } else if (choice == 0) {
                                                    j = trains.get(trains.size() - 1).getWagons().get(trains.get(trains.size() - 1).getWagons().size() - 1).getWagonCapacity();
                                                }
                                                else {
                                                    System.out.println("Choose the number from the list!");
                                                }
                                            }
                                        } else {
                                            System.out.println("Passenger is not a child");
                                        }

                                    }}
                            }else if(choice == 2){
                                System.out.println("Number of passanger?");
                                int num2 = sc.nextInt();
                                passengerManage();
                                System.out.println("Choose action: ");
                                System.out.println("1. Set new name");
                                System.out.println("2. Set new surname");
                                System.out.println("3. Set new age");
                                System.out.println("0. Go back");
                                System.out.println();
                                choice = sc.nextInt();
                                if(choice == 1){
                                    System.out.println("Write your new name: ");
                                    String str = sc.next();
                                    trains.get(num-1).getWagons().get(num1-1).getPassengers().get(num2-1).setName(str);
                                    System.out.println("Data has been updated");
                                } else if (choice == 2) {
                                    System.out.println("Write your new surname: ");
                                    String str = sc.next();
                                    trains.get(num-1).getWagons().get(num1-1).getPassengers().get(num2-1).setSecondName(str);
                                    System.out.println("Data has been updated");
                                } else if (choice == 3) {
                                    System.out.println("Write your new age: ");
                                    int temp = sc.nextInt();
                                    trains.get(num-1).getWagons().get(num1-1).getPassengers().get(num2-1).setAge(temp);
                                    System.out.println("Data has been updated");
                                } else if (choice == 0) {
                                    continue;
                                }
                                else {
                                    System.out.println("Choose the number from the list!");
                                }
                            }else if(choice == 3){
                                System.out.println("Passenger number?");
                                int num2 = sc.nextInt();
                                trains.get(num-1).getWagons().get(num1-1).getPassengers().remove(num2-1);
                                System.out.println("Data has been updated");
                            }else if(choice == 0){
                                continue;
                            }
                            else {
                                System.out.println("Choose the number from the list!");
                            }
                        } else if (choice == 0) {
                            continue;
                        }
                        else {
                            System.out.println("Choose the number from the list!");
                        }
                    } else if(choice == 0){
                        continue;
                    }
                    else {
                        System.out.println("Choose the number from the list!");
                    }
                } else if (choice == 0) {
                    continue;
                }
                else {
                    System.out.println("Choose the number from the list!");
                }
            } else if (choice == 0) {
                System.exit(0);
            }
            else {
                System.out.println("Choose the number from the list!");
            }
        }
    }
}