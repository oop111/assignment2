package com.aitu.assignment2.train.wagons;
import com.aitu.assignment2.train.wagons.passengers.Passenger;
import com.aitu.assignment2.train.wagons.passengers.Child;
import com.aitu.assignment2.train.wagons.passengers.Retired;
import com.aitu.assignment2.train.wagons.passengers.Student;

import java.util.ArrayList;
import java.util.Scanner;
public class Restaurant extends Wagon implements IWagon{
    public Restaurant(int wagonCapacity){
        super(wagonCapacity);
        wagonName = "Restaurant";
        passengers = new ArrayList<Passenger>();
        wagonNum = Wagon.wagonSum;
        Wagon.wagonSum++;
        price = 2000;
    }
    @Override
    public void seatPrice(Passenger p) {
        if(p.getClass() == Student.class){
            p.setPrice(1000);
        } else if(p.getClass() == Retired.class){
            p.setPrice(500);
        } else if(p.getClass() == Child.class){
            p.setPrice(0);
        } else {
            p.setPrice(2000);
        }
    }
    @Override
    public void enrollPassengers(ArrayList<Passenger> passengers){
        if(wagonCapacity < (passengers.size() + this.passengers.size())){
            System.out.println("Not enough places");
        }
        else{
            for(Passenger p : passengers){
                this.passengers.add(p);
                seatPrice(p);
            }
        }
    }
    @Override
    public void enrollPassenger(Passenger passenger){
        if((wagonCapacity >= (1 + this.passengers.size())) || (this.passengers.size() == 0)){
            this.passengers.add(passenger);
            seatPrice(this.passengers.get(this.passengers.size() - 1));
        }else{
            System.out.println("Not enough space");
        }
    }
    public void order(Passenger passenger){
        Scanner sc = new Scanner(System.in);
        System.out.println("What do you want to order");
        String a = sc.next();
        System.out.println(passenger.getName() + " ordered " + a);
    }
}
