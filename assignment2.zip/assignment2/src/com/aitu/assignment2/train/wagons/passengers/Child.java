package com.aitu.assignment2.train.wagons.passengers;

public class Child extends Passenger {
    public Child(int seat, String name, String secondName, int age){
        super(seat, name, secondName, age);
    }
}
