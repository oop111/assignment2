package com.aitu.assignment2.train.wagons.passengers;

public class Student extends Passenger{
    private int price;
    public Student(int seat, String name, String secondName, int age){
        super(seat, name, secondName, age);
    }
}
