package com.aitu.assignment2.train.wagons;
import com.aitu.assignment2.train.wagons.passengers.Passenger;
import com.aitu.assignment2.train.wagons.passengers.Child;
import com.aitu.assignment2.train.wagons.passengers.Retired;
import com.aitu.assignment2.train.wagons.passengers.Student;

import java.util.ArrayList;

public class DisWagon extends Wagon implements IWagon{
    public DisWagon(int wagonCapacity){
        super(wagonCapacity);
        wagonName = "Wagon for disabled people";
        passengers = new ArrayList<Passenger>();
        wagonNum = Wagon.wagonSum;
        Wagon.wagonSum++;
        price = 5000;
        seats = new ArrayList<Integer>();
        int n = 0;
        for(int i = 0; i < wagonCapacity; i++){
            n++;
            seats.add(n);
        }
    }
    @Override
    public void seatPrice(Passenger p) {
        if(p.getClass() == Student.class){
            p.setPrice(4000);
        } else if(p.getClass() == Retired.class){
            p.setPrice(3000);
        } else if(p.getClass() == Child.class){
            p.setPrice(0);
        } else {
            p.setPrice(5000);
        }
    }
    @Override
    public void enrollPassengers(ArrayList<Passenger> passengers){
        if(wagonCapacity < (passengers.size() + this.passengers.size())){
            System.out.println("Not enough places");
        } else{
            int sum = 0;
            for(Passenger pass: passengers){
                for(Integer s: this.seats){
                    if(s == pass.getSeat()){
                        this.passengers.add(pass);
                        this.seats.remove(s);
                        seatPrice(pass);
                        sum = 0;
                        break;
                    }
                    else{
                        sum++;
                    }
                }
                if(sum > 0){
                    System.out.println("Select seats from this table:"+getSeats());
                }
            }

        }
    }
    @Override
    public void enrollPassenger(Passenger passenger){
        if(wagonCapacity >= (1 + this.passengers.size())){
            int sum = 0;
            for(Integer s: this.seats){
                if(s == passenger.getSeat()){
                    this.passengers.add(passenger);
                    this.seats.remove(s);
                    seatPrice(this.passengers.get(this.passengers.size() - 1));
                    sum = 0;
                    break;
                }
                else{
                    sum++;
                }
            }
            if(sum > 0){
                System.out.println("Select seats from this table:"+getSeats());
            }
        }
        else{
            System.out.println("Not enough places");
        }
    }
}
