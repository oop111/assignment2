package com.aitu.assignment2.train.wagons.passengers;
public interface IPassengers {
}
