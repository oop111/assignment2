package com.aitu.assignment2.train.wagons.passengers;
import com.aitu.assignment2.train.wagons.IWagon;
import com.aitu.assignment2.train.wagons.Wagon;
import java.util.ArrayList;
public class Passenger{
    private int seat;
    private String name;
    private String secondName;
    private int price;
    private int age;
    public Passenger(int seat, String name, String secondName, int age){
        this.seat = seat;
        this.name = name;
        this.secondName = secondName;
        this.age = age;

    }
    public Passenger(int seat, String name, String secondName, int age, int price){
        this.seat = seat;
        this.name = name;
        this.secondName = secondName;
        this.age = age;
        this.price = price;
    }
    public String getName() {
        return name;
    }
    public int getAge() {
        return age;
    }
    public int getSeat() {
        return seat;
    }
    public String getSecondName() {
        return secondName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public void setSeat(int seat) {
        this.seat = seat;
    }
    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    @Override
    public String toString() {
        return "Name: " + name + " " + secondName +'\n' + "Age: " + age +'\n' + "Ticket price: " + this.price +'\n'+'\n';
    }
}