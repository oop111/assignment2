package com.aitu.assignment2.train.wagons;
import com.aitu.assignment2.train.wagons.passengers.Passenger;
import com.aitu.assignment2.train.wagons.passengers.Child;
import com.aitu.assignment2.train.wagons.passengers.Retired;
import com.aitu.assignment2.train.wagons.passengers.Student;

public interface IWagon {
    public void seatPrice(Passenger p);
}