package com.aitu.assignment2.train.wagons;
import com.aitu.assignment2.train.wagons.passengers.Passenger;
import java.util.ArrayList;
public class Wagon implements IWagon{
    protected static int wagonSum = 1;
    protected int wagonNum;
    protected String wagonName;
    protected int price;
    protected int wagonCapacity;
    protected ArrayList<Integer> seats;
    protected ArrayList<Passenger> passengers;
    public Wagon(){

    }
    public Wagon(int wagonCapacity){
        this.wagonCapacity = wagonCapacity;
        wagonNum = wagonSum;
        seats = new ArrayList<Integer>();
        int n = 0;
        for(int i = 0; i < wagonCapacity; i++){
            n++;
            seats.add(n);
        }
        passengers = new ArrayList<Passenger>();
    }

    public void enrollPassengers(ArrayList<Passenger> passengers){
        if(wagonCapacity < (passengers.size() + this.passengers.size())){
            System.out.println("Not enough places");
        } else{
            int sum = 0;
            for(Passenger pass: passengers){
                for(Integer s: this.seats){
                    if(s == pass.getSeat()){
                        this.passengers.add(pass);
                        this.seats.remove(s);
                        sum = 0;
                        break;
                    }
                    else{
                        sum++;
                    }
                }
                if(sum > 0){
                    System.out.println("Select seats from this table:"+getSeats());
                }
            }

        }
    }

    @Override
    public void seatPrice(Passenger p) {

    }

    public void enrollPassenger(Passenger passenger){
        if(wagonCapacity >= (1 + this.passengers.size())){
            int sum = 0;
            for(Integer s: this.seats){
                if(s == passenger.getSeat()){
                    seatPrice(passenger);
                    this.passengers.add(passenger);
                    this.seats.remove(s);

                    sum = 0;
                    break;
                }
                else{
                    sum++;
                }
            }
            if(sum > 0){
                System.out.println("Select seats from this table:"+getSeats());
            }
        }
        else{
            System.out.println("Not enough places");
        }
    }
    public void removePassenger(Passenger passenger){
        this.seats.add(passenger.getSeat());
        this.passengers.remove(passenger);
    }
    public void removePassengers(ArrayList<Passenger> passengers){
        for(Passenger p : passengers){
            this.seats.add(p.getSeat());
            this.passengers.remove(p);
        }
    }

    public int getWagonCapacity() {
        return wagonCapacity;
    }

    public void setWagonCapacity(int wagonCapacity) {
        this.wagonCapacity = wagonCapacity;
    }

    public ArrayList<Passenger> getPassengers() {
        return passengers;
    }

    public void setPassengers(ArrayList<Passenger> passengers) {
        this.passengers = passengers;
    }

    public ArrayList<Integer> getSeats() {
        return seats;
    }

    public void setSeats(ArrayList<Integer> seats) {
        this.seats = seats;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getWagonNum() {
        return wagonNum;
    }

    public void setWagonNum(int wagonNum) {
        this.wagonNum = wagonNum;
    }

    public static int getWagonSum() {
        return wagonSum;
    }

    public static void setWagonSum(int wagonSum) {
        Wagon.wagonSum = wagonSum;
    }

    public String getWagonName() {
        return wagonName;
    }

    public void setWagonName(String wagonName) {
        this.wagonName = wagonName;
    }

    @Override
    public String toString() {
        return "_____________________________"+'\n'+"Wagon №" + wagonNum +'\n'+
                "Wagon type: " + wagonName + '\n' +
                "Ticket price: " + price + '\n'+
                "Wagon capacity: " + wagonCapacity+ '\n' +"_____________________________" + '\n';
    }
}
