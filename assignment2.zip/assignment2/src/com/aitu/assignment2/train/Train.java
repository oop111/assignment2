package com.aitu.assignment2.train;
import com.aitu.assignment2.train.wagons.Wagon;
import com.aitu.assignment2.train.wagons.passengers.Passenger;

import java.util.ArrayList;
public class Train {
    protected static int trainSum = 1;
    protected int trainNum;
    private String direction;
    private String time;
    protected int amountOfWagons;
    private int speed;
    private int trainCapacity = 0;
    private String trainType;
    Wagon wagon = new Wagon();
    private ArrayList<Wagon> wagons;
    public Train(){

    }
    public Train(String direction, String time, int amountOfWagons, int speed, String trainType){
        setDirection(direction);
        setTime(time);
        setAmountOfWagons(amountOfWagons);
        setSpeed(speed);
        setTrainType(trainType);
        trainNum = trainSum;
        wagons = new ArrayList<Wagon>();
    }
    public void enrollWagons(ArrayList<Wagon> wagons){
        if(amountOfWagons < (wagons.size() + this.wagons.size())){
            System.out.println("Too many wagons");
        }
        else{
            for(Wagon w : wagons){
                this.wagons.add(w);
            }
        }
    }
    public void enrollWagon(Wagon wagon){
        if((1 + this.wagons.size()) > amountOfWagons){
            System.out.println("Too many wagons");
        }
        else{
            this.wagons.add(wagon);
        }
    }
    public void removeWagon(Wagon wagon){
        this.wagons.remove(wagon);
    }
    public void removeWagons(ArrayList<Wagon> wagons){
        this.wagons.removeAll(wagons);
    }
    public String getDirection() {
        return direction;
    }
    public void setDirection(String direction) {
        this.direction = direction;
    }
    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public int getAmountOfWagons() {
        return amountOfWagons;
    }
    public void setAmountOfWagons(int amountOfWagons) {
        this.amountOfWagons = amountOfWagons;
    }
    public int getSpeed() {
        return speed;
    }
    public void setSpeed(int speed) {
        this.speed = speed;
    }
    public int getTrainCapacity() {
        for(Wagon w: wagons){
            trainCapacity += w.getWagonCapacity();
        }
        return trainCapacity;
    }
    public void setTrainCapacity(int trainCapacity) {
        this.trainCapacity = trainCapacity;
    }

    public ArrayList<Wagon> getWagons() {
        return wagons;
    }

    public void setWagons(ArrayList<Wagon> wagons) {
        this.wagons = wagons;
    }

    public String getTrainType() {
        return trainType;
    }

    public void setTrainType(String trainType) {
        this.trainType = trainType;
    }

    public Wagon getWagon() {
        return wagon;
    }
    public Wagon getWagon(int i) {
        return this.wagons.get(i);
    }

    public void setWagon(Wagon wagon) {
        this.wagon = wagon;
    }

    @Override
    public String toString() {
        return "_____________________________"+'\n'+"Train №" + trainNum +'\n'+"Train type: " + trainType +'\n'+
                "Direction: " + direction + '\n' +
                "Time: " + time + '\n' +
                "Max amount of wagons: " + amountOfWagons +'\n'+
                "Speed: " + speed  +'\n'+
                "Train capacity:" + getTrainCapacity() +'\n' + "_____________________________" +'\n';
    }
}
